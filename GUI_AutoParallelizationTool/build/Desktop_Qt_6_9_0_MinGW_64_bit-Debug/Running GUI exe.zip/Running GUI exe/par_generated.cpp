
    #include <mpi.h>
    #include <vector>
    #include <algorithm>
    #include <iostream>
    #include <cstdint>
    #include <cstdlib>
    #include <fstream>

    void median_filter_kernel(const std::vector<uint8_t>& local_image,
                              std::vector<uint8_t>& local_output,
                              int width, int rows, int k, int r,
                              int rank, int rows_per_proc, int global_height) {
        std::vector<uint8_t> window;
        window.reserve(k * k);
        for (int y = 0; y < rows; ++y) {
            int global_y = rank * rows_per_proc + y;
            for (int x = 0; x < width; ++x) {
                window.clear();
                int center_y = y + r;
                for (int dy = -r; dy <= r; ++dy) {
                    int local_ny = center_y + dy;
                    int global_ny = global_y + dy;

                    for (int dx = -r; dx <= r; ++dx) {
                        int nx = x + dx;

                        // Boundary Checks
                        if (nx < 0 || nx >= width) continue;
                        if (global_ny < 0 || global_ny >= global_height) continue;

                        window.push_back(local_image[local_ny * width + nx]);
                    }
                }
                std::sort(window.begin(), window.end());
                local_output[y * width + x] = window[window.size() / 2];
            }
        }
    }

    int main(int argc, char* argv[]) {
        MPI_Init(&argc, &argv);
        int rank, size;
        MPI_Comm_rank(MPI_COMM_WORLD, &rank);
        MPI_Comm_size(MPI_COMM_WORLD, &size);

        int width = 4096;
        int height = 4096;
        int k = 5;
        int r = k / 2;
        int rows_per_proc = height / size;

        std::vector<uint8_t> full_image;
        std::vector<uint8_t> final_output;

        double t_comm = 0.0, t_calc = 0.0;

        if (rank == 0) {
            full_image.resize(width * height);

            // UPDATED: Read from "check/input_image.raw"
            std::ifstream in("check/input_image.raw", std::ios::binary);
            if(in) {
                in.read(reinterpret_cast<char*>(full_image.data()), full_image.size());
                in.close();
            } else {
                 std::cerr << "[Error] Could not open check/input_image.raw" << std::endl;
                 MPI_Abort(MPI_COMM_WORLD, 1);
            }
            final_output.resize(width * height);
        }

        std::vector<uint8_t> my_chunk(rows_per_proc * width);

        double t0_comm = MPI_Wtime();
        MPI_Scatter(full_image.data(), rows_per_proc * width, MPI_UNSIGNED_CHAR,
                    my_chunk.data(), rows_per_proc * width, MPI_UNSIGNED_CHAR,
                    0, MPI_COMM_WORLD);
        t_comm += (MPI_Wtime() - t0_comm);

        MPI_Barrier(MPI_COMM_WORLD);
        double t0 = MPI_Wtime();

        double t1_comm = MPI_Wtime();
        std::vector<uint8_t> padded_chunk((rows_per_proc + 2 * r) * width, 0);
        std::copy(my_chunk.begin(), my_chunk.end(),
                  padded_chunk.begin() + (r * width));

        MPI_Request reqs[4];
        int n_reqs = 0;

        if (rank > 0) {
            MPI_Irecv(padded_chunk.data(), r * width, MPI_UNSIGNED_CHAR,
                      rank - 1, 0, MPI_COMM_WORLD, &reqs[n_reqs++]);
            MPI_Isend(padded_chunk.data() + r * width, r * width,
                      MPI_UNSIGNED_CHAR, rank - 1, 1, MPI_COMM_WORLD,
                      &reqs[n_reqs++]);
        }
        if (rank < size - 1) {
            MPI_Isend(padded_chunk.data() + rows_per_proc * width, r * width,
                      MPI_UNSIGNED_CHAR, rank + 1, 0, MPI_COMM_WORLD,
                      &reqs[n_reqs++]);
            MPI_Irecv(padded_chunk.data() + (rows_per_proc + r) * width,
                      r * width, MPI_UNSIGNED_CHAR, rank + 1, 1,
                      MPI_COMM_WORLD, &reqs[n_reqs++]);
        }
        if (n_reqs > 0) MPI_Waitall(n_reqs, reqs, MPI_STATUSES_IGNORE);
        t_comm += (MPI_Wtime() - t1_comm);

        double t0_calc = MPI_Wtime();
        std::vector<uint8_t> my_output(rows_per_proc * width);
        median_filter_kernel(padded_chunk, my_output, width,
                             rows_per_proc, k, r, rank, rows_per_proc, height);
        t_calc += (MPI_Wtime() - t0_calc);

        double t2_comm = MPI_Wtime();
        MPI_Gather(my_output.data(), rows_per_proc * width, MPI_UNSIGNED_CHAR,
                   rank == 0 ? final_output.data() : nullptr,
                   rows_per_proc * width, MPI_UNSIGNED_CHAR,
                   0, MPI_COMM_WORLD);
        t_comm += (MPI_Wtime() - t2_comm);

        double t1 = MPI_Wtime();
        if (rank == 0) {
            std::cout << "[Profile] Comm: " << t_comm << " s, Calc: " << t_calc << " s" << std::endl;
            std::ofstream tfile("analysis/parallel_time.txt");
            tfile << (t1 - t0);
            tfile.close();

             // UPDATED: Write to "check/par_output.raw"
             std::ofstream img_file("check/par_output.raw", std::ios::binary);
            img_file.write(reinterpret_cast<const char*>(final_output.data()),
                   final_output.size());
            img_file.close();
        }
        MPI_Finalize();
        return 0;
    }
    